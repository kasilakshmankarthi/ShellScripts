#!/bin/sh

export PVTRACEDIR=/home/natty/software/pvrsdk/android/SDKPackage_OGLES2/Utilities/PVRTrace
export PVRTRACELIBSDIR=Recorder/AndroidARMV7

adb remount
adb shell rm /system/lib/libPVRTrace.so
adb shell rm /system/vendor/lib/egl/libEGL_PVRTRACE.so
adb shell rm /system/vendor/lib/egl/libGLESv2_PVRTRACE.so
adb shell rm /system/vendor/lib/egl/libGLESv1_CM_PVRTRACE.so

adb push $PVTRACEDIR/$PVRTRACELIBSDIR/libPVRTrace.so /system/lib/
adb push $PVTRACEDIR/$PVRTRACELIBSDIR/libEGL_PVRTRACE.so /system/vendor/lib/egl/
adb push $PVTRACEDIR/$PVRTRACELIBSDIR/libGLESv2_PVRTRACE.so /system/vendor/lib/egl/
adb push $PVTRACEDIR/$PVRTRACELIBSDIR/libGLESv1_CM_PVRTRACE.so /system/vendor/lib/egl/

adb push ./pvrtrace.cfg /mnt/sdcard/

adb shell sync

echo
echo '*************************************************'
echo 'make sure /system/lig/egl/egl.cfg is updated from'
echo '0 1 POWERVR_SGX_540_120'
echo 'to'
echo '0 1 PVRTRACE'
echo 'after backing up the original egl.cfg'
echo '*************************************************'
